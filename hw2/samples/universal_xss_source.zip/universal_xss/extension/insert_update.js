// pretend there's fancy CSS here
$("body").prepend(`<h1>Your page has been updated in tab ${title}</h1>`)